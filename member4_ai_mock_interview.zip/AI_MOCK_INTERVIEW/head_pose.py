import cv2
import mediapipe as mp
import numpy as np

# ----------------------------------------
# Initialize Face Mesh
# ----------------------------------------
mp_face_mesh = mp.solutions.face_mesh

face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False,
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# ----------------------------------------
# Open Webcam
# ----------------------------------------
cap = cv2.VideoCapture(0)

while True:

    success, frame = cap.read()

    if not success:
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    results = face_mesh.process(rgb)

    img_h, img_w, img_c = frame.shape

    face_2d = []
    face_3d = []

    nose_2d = None
    nose_3d = None

    if results.multi_face_landmarks:

        for face_landmarks in results.multi_face_landmarks:

            for idx, lm in enumerate(face_landmarks.landmark):

                if idx in [33, 263, 1, 61, 291, 199]:

                    x = int(lm.x * img_w)
                    y = int(lm.y * img_h)

                    face_2d.append([x, y])

                    face_3d.append([x, y, lm.z])

                    # Save Nose Coordinates
                    if idx == 1:
                        nose_2d = (x, y)
                        nose_3d = (x, y, lm.z)

                    cv2.circle(frame, (x, y), 3, (0, 255, 0), -1)

            face_2d = np.array(face_2d, dtype=np.float64)
            face_3d = np.array(face_3d, dtype=np.float64)

            # Camera Matrix
            focal_length = img_w

            cam_matrix = np.array([
                [focal_length, 0, img_w / 2],
                [0, focal_length, img_h / 2],
                [0, 0, 1]
            ])

            dist_matrix = np.zeros((4, 1), dtype=np.float64)

            success, rot_vec, trans_vec = cv2.solvePnP(
                face_3d,
                face_2d,
                cam_matrix,
                dist_matrix
            )

            rmat, jac = cv2.Rodrigues(rot_vec)

            angles, mtxR, mtxQ, Qx, Qy, Qz = cv2.RQDecomp3x3(rmat)

            pitch = angles[0] * 360
            yaw = angles[1] * 360
            roll = angles[2] * 360

            # -------------------------
            # Calculate Nose Direction
            # -------------------------

            nose_end_x = int(nose_2d[0] + yaw * 10)
            nose_end_y = int(nose_2d[1] - pitch * 10)

            cv2.line(
                frame,
                nose_2d,
                (nose_end_x, nose_end_y),
                (255, 0, 0),
                3
            )

            # -------------------------
            # Head Direction
            # -------------------------

            if yaw < -10:
                text = "Looking Left"

            elif yaw > 10:
                text = "Looking Right"

            elif pitch < -10:
                text = "Looking Down"

            elif pitch > 10:
                text = "Looking Up"

            else:
                text = "Forward"

            cv2.putText(
                frame,
                f"Pitch : {pitch:.2f}",
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                f"Yaw : {yaw:.2f}",
                (20, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                f"Roll : {roll:.2f}",
                (20, 110),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

            cv2.putText(
                frame,
                text,
                (20, 155),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 0, 255),
                2
            )

    cv2.imshow("Head Pose Estimation", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()