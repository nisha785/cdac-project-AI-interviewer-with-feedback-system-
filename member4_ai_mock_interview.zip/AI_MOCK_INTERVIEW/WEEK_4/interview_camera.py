"""
interview_camera.py

Week 3 + Week 4

Main Interview Camera

Features
--------
✓ Open webcam
✓ Face crop
✓ Emotion Detection
✓ Head Pose Estimation
✓ Live Feedback
✓ Week 4 Answer Summary
✓ JSON Output
"""

import os
import sys
from unittest import result
from unittest import result
import cv2
import json
from datetime import datetime
from PIL import Image
from sklearn import metrics
from tensorboard import summary
from tensorboard import summary

# -------------------------------------------------
# Project Paths
# -------------------------------------------------

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)

sys.path.append(PROJECT_ROOT)
sys.path.append(os.path.join(PROJECT_ROOT, "WEEK_2"))
sys.path.append(os.path.join(PROJECT_ROOT, "week3"))
sys.path.append(os.path.join(PROJECT_ROOT, "WEEK_4"))

# -------------------------------------------------
# Imports
# -------------------------------------------------

from face_crop import crop_face
from emotion_detector import predict_emotion

from head_pose_utils import get_head_pose
from interview_analyzer import analyze_interview

from answer_summary import AnswerSummary
from performance_monitor import PerformanceMonitor


# -------------------------------------------------
# Output File
# -------------------------------------------------

OUTPUT_JSON = "interview_output.json"

# -------------------------------------------------
# Main
# -------------------------------------------------

def main():

    print("=" * 60)
    print(" AI MOCK INTERVIEW ")
    print("=" * 60)

    cap = cv2.VideoCapture(0)

    if not cap.isOpened():

        print("Unable to open webcam.")

        return

    print("\nPress Q to finish interview.\n")

    summary = AnswerSummary()
    monitor = PerformanceMonitor()

    last_result = None

    while True:

        success, frame = cap.read()
        monitor.update()

        if not success:

            break

        display = frame.copy()

        # -----------------------------------------
        # Face Crop
        # -----------------------------------------

        face, bbox = crop_face(frame)

        if face is not None:

            x, y, w, h = bbox

            cv2.rectangle(

                display,

                (x, y),

                (x + w, y + h),

                (0, 255, 0),

                2

            )

            # -----------------------------------------
            # Emotion
            # -----------------------------------------

            rgb = cv2.cvtColor(

                face,

                cv2.COLOR_BGR2RGB

            )

            pil_image = Image.fromarray(rgb)

            emotion, confidence, scores = predict_emotion(

                pil_image

            )

            # -----------------------------------------
            # Head Pose
            # -----------------------------------------

            pitch, yaw, roll = get_head_pose(

                frame

            )

            # -----------------------------------------
            # Interview Analysis
            # -----------------------------------------

            result = analyze_interview(

                emotion,

                confidence,

                pitch,

                yaw,

                roll

            )
            metrics = monitor.get_metrics()

            fps = metrics["fps"]
            cpu = metrics["cpu"]
            ram = metrics["ram"]
            

            last_result = result

            # -----------------------------------------
            # Week 4 Summary
            # -----------------------------------------

            summary.add_frame(

                emotion,

                confidence,

                pitch,

                yaw,

                roll

            )

            # -----------------------------------------
            # Display
            # -----------------------------------------

            cv2.putText(

                display,

                f"Emotion : {emotion}",

                (20, 35),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.7,

                (0, 255, 0),

                2

            )

            cv2.putText(

                display,

                f"Confidence : {confidence*100:.2f}%",

                (20, 70),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.7,

                (0, 255, 0),

                2

            )

            cv2.putText(

                display,

                f"Pitch : {pitch}",

                (20, 110),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.7,

                (255,255,0),

                2

            )

            cv2.putText(

                display,

                f"Yaw : {yaw}",

                (20,145),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.7,

                (255,255,0),

                2

            )

            cv2.putText(

                display,

                f"Roll : {roll}",

                (20,180),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.7,

                (255,255,0),

                2

            )

            cv2.putText(

                display,

                f"Score : {result['score']}",

                (20,220),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.7,

                (0,255,255),

                2

            )


            cv2.putText(
                display,
                f"FPS : {fps}",
                (20,250),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255,255,255),2)
            cv2.putText(display,f"CPU : {cpu} %",(20,285),cv2.FONT_HERSHEY_SIMPLEX,0.7,(255,255,255),2)
            cv2.putText(display,f"RAM : {ram} %",(20,320),cv2.FONT_HERSHEY_SIMPLEX,0.7,(255,255,255),2)
            y_text = 360

            cv2.putText(

                display,

                "Feedback:",

                (20, y_text),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.7,

                (255,255,255),

                2

            )

            y_text += 30

            for feedback in result["feedback"]:

                cv2.putText(

                    display,

                    "- " + feedback,

                    (30, y_text),

                    cv2.FONT_HERSHEY_SIMPLEX,

                    0.6,

                    (255,255,255),

                    2

                )

                y_text += 30

        else:

            cv2.putText(

                display,

                "No Face Detected",

                (20,40),

                cv2.FONT_HERSHEY_SIMPLEX,

                0.8,

                (0,0,255),

                2

            )

        cv2.imshow(

            "AI Mock Interview",

            display

        )

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):

            break

            # -------------------------------------------------
    # Release Camera
    # -------------------------------------------------

    cap.release()

    cv2.destroyAllWindows()

    # -------------------------------------------------
    # Week 4 Answer Summary
    # -------------------------------------------------

    interview_summary = summary.generate_summary()

    print("\n" + "=" * 60)
    print("INTERVIEW SUMMARY")
    print("=" * 60)

    print(f"Total Frames           : {interview_summary['total_frames']}")
    print(f"Dominant Emotion       : {interview_summary['dominant_emotion']}")
    print(f"Average Confidence     : {interview_summary['average_confidence']:.2f}")
    print(f"Average Pitch          : {interview_summary['average_pitch']}")
    print(f"Average Yaw            : {interview_summary['average_yaw']}")
    print(f"Average Roll           : {interview_summary['average_roll']}")
    print(f"Eye Contact Percentage : {interview_summary['eye_contact_percentage']} %")

    print("\nEmotion Distribution")

    for emotion, percentage in interview_summary[
        "emotion_percentages"
    ].items():

        print(f"{emotion:15s}: {percentage:.2f}%")

    # -------------------------------------------------
    # Save JSON
    # -------------------------------------------------

    output = {

        "timestamp":

            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),

        "last_frame":

            last_result,

        "answer_summary":

            interview_summary

    }

    with open(

        OUTPUT_JSON,

        "w",

        encoding="utf-8"

    ) as file:

        json.dump(

            output,

            file,

            indent=4

        )

    print("\nInterview report saved.")

    print(OUTPUT_JSON)

    print("=" * 60)


# -------------------------------------------------
# Main
# -------------------------------------------------

if __name__ == "__main__":

    main()