# Vision Model Card

## Project
AI Mock Interview System

---

## Vision Module

This module analyzes the interview candidate using computer vision.

Functions:
- Face Detection
- Face Cropping
- Emotion Detection
- Head Pose Estimation
- Eye Contact Estimation
- Interview Feedback
- Performance Monitoring

---

## Emotion Model

Model Name:
dima806/facial_emotions_image_detection

Framework:
Hugging Face Transformers

Language:
Python

Input:
RGB Face Image

Output Classes:
- Angry
- Disgust
- Fear
- Happy
- Neutral
- Sad
- Surprise

---

## Head Pose

Library:
MediaPipe Face Mesh

Algorithm:
OpenCV solvePnP()

Outputs:
- Pitch
- Yaw
- Roll

---

## Eye Contact

Rule:
Yaw within ±15° is considered eye contact.

---

## Confidence Threshold

Emotion predictions below 70% confidence are labeled as:

uncertain

---

## Performance Metrics

Displays:
- FPS
- CPU Usage
- RAM Usage

---

## Output

Generated interview_output.json contains:

- Emotion
- Confidence
- Head Pose
- Interview Score
- Feedback
- Emotion Distribution
- Average Head Pose
- Performance Metrics

---

## Limitations

- Single face supported
- Performance decreases in poor lighting
- Face masks may reduce emotion accuracy