"""
performance_monitor.py

Week 4

Measures:

- FPS
- CPU Usage
- RAM Usage

Used during live interview.
"""

import time
import psutil


class PerformanceMonitor:

    def __init__(self):

        self.start_time = time.time()

        self.frame_count = 0

    # -----------------------------

    def update(self):

        self.frame_count += 1

    # -----------------------------

    def get_fps(self):

        elapsed = time.time() - self.start_time

        if elapsed == 0:

            return 0

        return round(self.frame_count / elapsed, 2)

    # -----------------------------

    def get_cpu(self):

        return psutil.cpu_percent(interval=0)

    # -----------------------------

    def get_ram(self):

        return psutil.virtual_memory().percent

    # -----------------------------

    def get_metrics(self):

        return {

            "fps": self.get_fps(),

            "cpu": self.get_cpu(),

            "ram": self.get_ram()

        }


# -------------------------------------
# Test
# -------------------------------------

if __name__ == "__main__":

    monitor = PerformanceMonitor()

    for i in range(100):

        monitor.update()

        time.sleep(0.02)

    print(monitor.get_metrics())