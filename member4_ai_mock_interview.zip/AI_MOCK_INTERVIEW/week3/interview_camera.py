"""
interview_camera.py

Week 3 Main Program

Features:
- Opens webcam
- Crops face
- Detects emotion
- Calculates head pose
- Generates interview feedback
- Displays results
- Saves interview_output.json
- Press Q to quit
"""

import os
import sys
import cv2
import json

from PIL import Image
from datetime import datetime

# ---------------------------------------------------
# Add project folders to Python Path
# ---------------------------------------------------

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)

sys.path.append(os.path.join(PROJECT_ROOT, "WEEK_2"))
sys.path.append(os.path.join(PROJECT_ROOT, "week3"))

# ---------------------------------------------------
# Imports
# ---------------------------------------------------

from face_crop import crop_face
from emotion_detector import predict_emotion
from head_pose_utils import get_head_pose
from interview_analyzer import analyze_interview


def main():

    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Unable to open webcam.")
        return

    print("Press Q to Quit")

    last_result = None

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        display_frame = frame.copy()

        # ---------------------------------
        # Face Crop
        # ---------------------------------

        face, bbox = crop_face(frame)

        if face is not None:

            x, y, w, h = bbox

            cv2.rectangle(
                display_frame,
                (x, y),
                (x + w, y + h),
                (0, 255, 0),
                2
            )

            # -----------------------------
            # Convert OpenCV -> PIL
            # -----------------------------

            face_rgb = cv2.cvtColor(
                face,
                cv2.COLOR_BGR2RGB
            )

            pil_face = Image.fromarray(face_rgb)

            # -----------------------------
            # Emotion Detection
            # -----------------------------

            emotion, confidence, scores = predict_emotion(
                pil_face
            )

            confidence *= 100

            # -----------------------------
            # Head Pose
            # -----------------------------

            pitch, yaw, roll = get_head_pose(frame)

            # -----------------------------
            # Interview Analysis
            # -----------------------------

            result = analyze_interview(
                emotion,
                confidence,
                pitch,
                yaw,
                roll
            )

            last_result = result

            # -----------------------------
            # Display
            # -----------------------------

            cv2.putText(
                display_frame,
                f"Emotion : {emotion}",
                (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2
            )

            cv2.putText(
                display_frame,
                f"Confidence : {confidence:.2f} %",
                (20, 60),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 0),
                2
            )

            cv2.putText(
                display_frame,
                f"Pitch : {pitch:.2f}" if pitch is not None else "Pitch : N/A",
                (20, 100),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )

            cv2.putText(
                display_frame,
                f"Yaw : {yaw:.2f}" if yaw is not None else "Yaw : N/A",
                (20, 130),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )

            cv2.putText(
                display_frame,
                f"Roll : {roll:.2f}" if roll is not None else "Roll : N/A",
                (20, 160),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )

            cv2.putText(
                display_frame,
                f"Score : {result['score']}",
                (20, 200),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 255),
                2
            )

            y_text = 240

            cv2.putText(
                display_frame,
                "Feedback:",
                (20, y_text),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )

            y_text += 30

            for item in result["feedback"]:

                cv2.putText(
                    display_frame,
                    "- " + item,
                    (30, y_text),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (255, 255, 255),
                    2
                )

                y_text += 30

        else:

            cv2.putText(
                display_frame,
                "No Face Detected",
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2
            )

        cv2.imshow(
            "AI Mock Interview",
            display_frame
        )

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

    # ---------------------------------
    # Save Last Result to JSON                  


    # ---------------------------------
    if last_result is not None:

        output = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "emotion": last_result["emotion"],
            "confidence": last_result["confidence"],
            "pitch": last_result["pitch"],
            "yaw": last_result["yaw"],
            "roll": last_result["roll"],
            "score": last_result["score"],
            "feedback": last_result["feedback"]
        }

        output_path = os.path.join(
            PROJECT_ROOT,
            "week3",
            "interview_output.json"
        )

        with open(output_path, "w") as json_file:
            json.dump(
                output,
                json_file,
                indent=4
            )

        print("\nInterview analysis saved successfully.")
        print(f"Output File : {output_path}")

    else:

        print("\nNo interview data available.")


if __name__ == "__main__":
    main()

