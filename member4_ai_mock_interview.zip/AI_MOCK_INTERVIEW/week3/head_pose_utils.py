"""
head_pose_utils.py

Utility functions for Head Pose Estimation.

Returns:
    pitch
    yaw
    roll

Uses:
    MediaPipe Face Mesh
    OpenCV solvePnP()
"""

import cv2
import mediapipe as mp
import numpy as np


# -----------------------------
# Initialize MediaPipe FaceMesh
# -----------------------------
mp_face_mesh = mp.solutions.face_mesh

face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False,
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)


# ---------------------------------------
# Landmark IDs
# ---------------------------------------

LANDMARK_IDS = [
    33,     # Left eye outer corner
    263,    # Right eye outer corner
    1,      # Nose tip
    61,     # Left mouth
    291,    # Right mouth
    199     # Chin
]


# ---------------------------------------
# 3D Face Model
# ---------------------------------------

FACE_3D = np.array([

    (-30.0, 40.0, -30.0),     # Left eye
    (30.0, 40.0, -30.0),      # Right eye
    (0.0, 0.0, 0.0),          # Nose
    (-25.0, -35.0, -20.0),    # Left mouth
    (25.0, -35.0, -20.0),     # Right mouth
    (0.0, -65.0, -5.0)        # Chin

], dtype=np.float64)


def get_head_pose(frame):
    """
    Calculates Pitch, Yaw and Roll.

    Parameters
    ----------
    frame : numpy.ndarray

    Returns
    -------
    pitch, yaw, roll
    """

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    results = face_mesh.process(rgb)

    if not results.multi_face_landmarks:
        return None, None, None

    face_landmarks = results.multi_face_landmarks[0]

    h, w, _ = frame.shape

    face_2d = []

    for idx in LANDMARK_IDS:

        lm = face_landmarks.landmark[idx]

        x = int(lm.x * w)
        y = int(lm.y * h)

        face_2d.append((x, y))

    face_2d = np.array(face_2d, dtype=np.float64)

    focal_length = w

    cam_matrix = np.array([

        [focal_length, 0, w / 2],
        [0, focal_length, h / 2],
        [0, 0, 1]

    ], dtype=np.float64)

    dist_matrix = np.zeros((4, 1), dtype=np.float64)

    success, rot_vec, trans_vec = cv2.solvePnP(

        FACE_3D,
        face_2d,
        cam_matrix,
        dist_matrix

    )

    if not success:
        return None, None, None
    rmat, _ = cv2.Rodrigues(rot_vec)

    angles, _, _, _, _, _ = cv2.RQDecomp3x3(rmat)

    pitch = float(angles[0])
    yaw = float(angles[1])
    roll = float(angles[2])

    # ---------------------------------------
    # Normalize angles to [-90, 90]
    # ---------------------------------------

    def normalize(angle):

        if angle > 90:
            angle = angle - 180

        elif angle < -90:
            angle = angle + 180

        return round(angle, 2)

    pitch = normalize(pitch)
    yaw = normalize(yaw)
    roll = normalize(roll)

    return pitch, yaw, roll