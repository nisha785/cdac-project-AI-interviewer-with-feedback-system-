"""
Test image prediction.
"""

from emotion_detector import predict_emotion


image_path = "sample.jpg"

emotion, confidence, scores = predict_emotion(image_path)


print("\n========== EMOTION SCORES ==========\n")

for label, score in scores.items():

    print(f"{label:12} : {score*100:.2f}%")

print("\n====================================")

print("\nFinal Prediction")

print("---------------------")

print("Emotion :", emotion)

print(f"Confidence : {confidence*100:.2f}%")