"""
Week 2 Final Webcam Emotion Detection

Pipeline

Webcam
    ↓
Face Detection
    ↓
Crop Face
    ↓
Hugging Face Emotion Model
    ↓
Display Emotion
    ↓
Save JSON Output
"""

import cv2
import json
import os
from datetime import datetime

from PIL import Image

from face_crop import crop_face
from emotion_detector import predict_emotion


# -----------------------------
# Create Output Folder
# -----------------------------

os.makedirs("output", exist_ok=True)


# -----------------------------
# Open Webcam
# -----------------------------

cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Unable to open webcam.")
    exit()

print("Webcam Started")
print("Press Q to Quit")


# -----------------------------
# Main Loop
# -----------------------------

while True:

    success, frame = cap.read()

    if not success:
        break

    # Detect Face
    face, box = crop_face(frame)

    if face is not None:

        rgb = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)

        image = Image.fromarray(rgb)

        emotion, confidence, scores = predict_emotion(image)

        confidence *= 100

        x, y, w, h = box

        # Draw Rectangle
        cv2.rectangle(
            frame,
            (x, y),
            (x + w, y + h),
            (0, 255, 0),
            2
        )

        # Confidence Threshold
        if confidence < 60:
            emotion = "Uncertain"

        # Draw Emotion
        cv2.putText(
            frame,
            f"{emotion} ({confidence:.1f}%)",
            (x, y - 10),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )

        # Save JSON Output
        output = {

            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),

            "emotion": emotion,

            "confidence": round(confidence, 2)

        }

        with open(
            "output/emotion_output.json",
            "w"
        ) as file:

            json.dump(
                output,
                file,
                indent=4
            )

    else:

        cv2.putText(
            frame,
            "No Face Detected",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            1,
            (0, 0, 255),
            2
        )

    cv2.imshow(
        "Week 2 Final Emotion Detector",
        frame
    )

    key = cv2.waitKey(1)

    if key & 0xFF == ord("q"):
        break


cap.release()

cv2.destroyAllWindows()