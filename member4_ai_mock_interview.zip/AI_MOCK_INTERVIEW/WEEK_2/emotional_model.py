"""
emotion_model.py

Loads the Hugging Face facial emotion detection model once
and returns the model + image processor.

Model:
dima806/facial_emotions_image_detection
"""

from transformers import AutoImageProcessor, AutoModelForImageClassification


MODEL_NAME = "dima806/facial_emotions_image_detection"


print("Loading Hugging Face Emotion Model...")
print("Please wait... This may take a minute the first time.")


processor = AutoImageProcessor.from_pretrained(MODEL_NAME)

model = AutoModelForImageClassification.from_pretrained(MODEL_NAME)


print("Emotion Model Loaded Successfully!")