import mediapipe as mp

print("MediaPipe Installed Successfully!")

print("Version:", mp.__version__)