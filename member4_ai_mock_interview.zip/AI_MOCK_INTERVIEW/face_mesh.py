import cv2
import mediapipe as mp

# ----------------------------
# Initialize MediaPipe Face Mesh
# ----------------------------
mp_face_mesh = mp.solutions.face_mesh
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False,
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# ----------------------------
# Open Webcam
# ----------------------------
cap = cv2.VideoCapture(0)

print("Press Q to Quit")

while True:

    success, frame = cap.read()

    if not success:
        print("Cannot read webcam.")
        break

    # Flip image
    frame = cv2.flip(frame, 1)

    # Convert BGR to RGB
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Process frame
    results = face_mesh.process(rgb)

    # Draw landmarks
    if results.multi_face_landmarks:
            # Draw landmarks

        for face_landmarks in results.multi_face_landmarks:

            height, width, _ = frame.shape

            # Landmark IDs
            landmark_ids = [1, 33, 263, 61, 291, 199]

            # Colors (BGR)
            colors = [
                (0, 0, 255),      # Nose - Red
                (255, 0, 0),      # Left Eye - Blue
                (0, 255, 0),      # Right Eye - Green
                (0, 255, 255),    # Left Mouth - Yellow
                (255, 255, 0),    # Right Mouth - Cyan
                (255, 0, 255)     # Chin - Pink
            ]

            for idx, landmark_id in enumerate(landmark_ids):

                landmark = face_landmarks.landmark[landmark_id]

                x = int(landmark.x * width)
                y = int(landmark.y * height)

                cv2.circle(frame, (x, y), 6, colors[idx], -1)

                cv2.putText(
                    frame,
                    str(landmark_id),
                    (x + 5, y - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    colors[idx],
                    2
                )

            mp_drawing.draw_landmarks(
                image=frame,
                landmark_list=face_landmarks,
                connections=mp_face_mesh.FACEMESH_TESSELATION,
                landmark_drawing_spec=None,
                connection_drawing_spec=mp_drawing_styles.get_default_face_mesh_tesselation_style()
            )

        

    cv2.imshow("MediaPipe Face Mesh", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()